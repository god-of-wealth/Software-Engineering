Page({  
  data: {
    range: 0.5,  //人为设定的界线
    score: 0.00, //系统抽出的随机数
    myChoice:0, //我选择执大执小
    randArea:"",
    who: ""
  },

  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数

  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  //获取输入的界线值
  bindKeyRangeInput: function (e) 
  {
    this.setData({
      range: e.detail.value
     
    })
    console.log(range);
  },

  radioChange: function(e)
  {
    this.setData({ myChoice: e.detail.value})
  },

  select_random: function (e) 
  {

    this.getRandom();
    this.whoDoWork();
    this.rand_range();
  },

  //计算随机值
  getRandom: function () {
    let score = Math.floor(Math.random() * 1000) / 1000;

    this.setData({
      score:score
    })

  },

  whoDoWork: function () 
  {   //显示谁做家务 
    let who="";
    let flag=0;

    if(this.data.score<this.data.range)
    {
      flag=0;
    }
    else flag=1;

    if(flag==this.data.myChoice)
    {
      this.setData( { who:"对方来做" })
    }
    else{
      this.setData({ who: "我来做" })
    }    
  },

  //随机数所在区域
  rand_range: function () 
  {
    let randArea="";

    if( this.data.score < this.data.range)
    {
      this.setData({ randArea: "小" })
    }
    else
    {
      this.setData({ randArea: "大" })
    }
  }

})