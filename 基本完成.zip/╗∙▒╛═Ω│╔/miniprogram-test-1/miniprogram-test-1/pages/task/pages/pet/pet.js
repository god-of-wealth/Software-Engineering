Page({

  /**
  * 页面的初始数据
  */
  data: {
    onFood: 1000, //饮食开销
    medicine: 600, //医疗
    happytime: 1000, //娱乐
    clothes: 200, //衣物
    conclusion: ""
  },

  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
  },

  /**
  * 生命周期函数--监听页面初次渲染完成
  */
  onReady: function () {
  },

  /**
  * 生命周期函数--监听页面显示
  */
  onShow: function () {
  },

  /**
  * 生命周期函数--监听页面隐藏
  */
  onHide: function () {
  },

  /**
  * 生命周期函数--监听页面卸载
  */
  onUnload: function () {
  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {
  },

  /**
  * 页面上拉触底事件的处理函数
  */
  onReachBottom: function () {
  },

  /**
  * 用户点击右上角分享
  */
  onShareAppMessage: function () {
  },

  onFoodInput: function (e) {
    this.setData({
      onFood: e.detail.value
    })
  },

  onClothesInput: function (e) {
    this.setData({
      clothes: e.detail.value
    })
  },

  radioChange: function (e) {
    this.setData({ medicine: e.detail.value })
  },

  radioChange2: function (e) {
    this.setData({ happytime: e.detail.value })
  },

  calculation: function (e) {
    var all = 0;
    var food = Number(this.data.onFood);
    var happy = Number(this.data.happytime);
    var clothes = Number(this.data.clothes);
    var all = food + happy + clothes;
    console.log("onFood: " + this.data.onFood);
    console.log("medicine: " + this.data.medicine);
    console.log("happytime: " + this.data.happytime);
    console.log("clothes: " + this.data.clothes);
    console.log("三个加和all" + all);
    all *= 12;
    console.log("乘了12的all: " + all);
    all += Number(this.data.medicine);

    console.log("加总all: " + all);

  
    let a = all;
    this.setData({ conclusion: a });
    wx.pageScrollTo({

      scrollTop: 0,

    })
  }

})