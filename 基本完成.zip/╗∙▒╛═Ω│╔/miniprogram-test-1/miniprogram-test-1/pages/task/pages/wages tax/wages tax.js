Page({
  data: {
    score: 0,
    income: 0,
    kouchu: 0,
    baoxian: 0,
    qishu:1, 
    index:0,
    a:0,
    toPay: 0, //扣5000的那个
    taxPayable: 0, //本期交税
    rate:0,

    array:['1','2','3','4','5','6','7','8','9','10','11','12'],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  bindKeyIncomeInput: function (e) {
    this.setData({
      income: e.detail.value
    })
  },

  bindKeyKouchuInput: function (e) {
    this.setData({
      kouchu: e.detail.value
    })
  },

  bindKeyBaoxianInput: function (e) {
    this.setData({
      baoxian: e.detail.value
    })
  },

  bindKeyQishuChange:function(e)
  {
    const a=e.detail.value;
    console.log("a: "+a);
     this.setData({
       index:a,
       qishu:Number(a)+1
     })
     console.log("index: "+this.data.index);
     console.log("\nqishu: "+this.data.qishu);
  },

  suanshui:function(a)
  {
    let b=0;
    console.log("\n传入suanshui的all: "+a);

    if (a > 960000) {
      b = a  * 0.45 - 181920;
      console.log("\n1");
      return Number(b);
      
    }
    else if (a > 660000) {
      b = a * 0.35 - 85920;
      console.log("\n2");
      return Number(b);
    }
    else if (a > 420000) {
      b = a * 0.3 - 52920;
      console.log("\n3");
      return Number(b);
    }
    else if (a > 300000) {
      b = a * 0.25 - 31920;
      console.log("\n4");
      console.log("\nb为： "+b);
      return Number(b);
    }
    else if (a > 144000) {
      b = a * 0.2 - 16920;
      console.log("\n5");
      return Number(b);
    }
    else if (a > 36000) {
      b =a  * 0.1 - 2520;
      console.log("\n6");
      return Number(b);
    }
    else {
      b = a * 0.03;
      console.log("\n7");
      return Number(b);
    }
  },

  suanrate: function (a) {
    if (a > 960000) {
     this.setData(
       {
         rate:"40%"
       }
     )
    }
    else if (a > 660000) {
      this.setData({
        rate: "35%"
      })
    }
    else if (a > 420000) {
      this.setData({
        rate: "30%"
      })

    }
    else if (a > 300000) {
      this.setData({
        rate: "25%"
      })

    }
    else if (a > 144000) {
      this.setData({
        rate: "20%"
      })

    }
    else if (a > 36000) {
      this.setData({
        rate: "10%"
      })

    }
    else {
      this.setData({
        rate: "3%"
      })

    }
  },
  
    jisuan:function(payable,qishu)
{
    var result;
    console.log("\njisuan函数处的payable: "+payable);


    qishu=Number(this.data.qishu);
    console.log("\njisuan函数处的期数" + qishu);
    if(qishu> 1)
{
      var all = Number(payable * qishu);
      console.log("\n累计算税all： "+all);

    result = Number(this.suanshui(all));
    console.log("\n算出来的总税款"+result);

    var a = Number(this.suanshui(payable * (qishu - 1)))
    console.log("\n应扣除部分"+a);

  return Number(result - a);

}
    else if (qishu == 1) {
      console.log("\nresult" + Number(this.suanshui(payable)));
  return Number(this.suanshui(payable));
}
else return 0;
},


  calculateBtn: function (e) {

    let a = this.data.income - this.data.baoxian - this.data.kouchu - 5000;
    if (a < 0) {
      a = 0;
      this.setData({
        toPay:0,
        taxPayable:0
      })
    }

    else {
      var qishu=Number(this.data.qishu);
      var xx;
      console.log("扣5000后的收入额: " + a);
      xx= this.jisuan(a, qishu);
      this.suanrate(a*qishu);

      console.log("算出来的计税: "+xx);


      this.setData(
        {
          toPay:a,
          taxPayable:Math.round(xx),
          score:this.data.income-this.data.baoxian-Math.round(xx)
        }
      )


    }
  },


})