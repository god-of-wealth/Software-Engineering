Page({
  data: {
    score: 0,
    income: 0,
    perMonth: "",
    taxPayable: "",
    rate:""


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  bindKeyIncomeInput: function (e) {
    this.setData({
      income: e.detail.value
    })
  },

  nianzhongjiang:function(money){
    var perm = money/12;
    let shuikuan = 0;

    if (perm > 80000){
      shuikuan = money*0.45-15160;
      return Number(shuikuan);
    }
    else if (perm > 55000){
      shuikuan = money*0.35-7160;
      return Number(shuikuan);
    }
    else if (perm > 35000) {
      shuikuan = money * 0.3 - 4410;
      return Number(shuikuan);
    }
    else if (perm > 25000) {
      shuikuan = money * 0.25 - 2660;
      return Number(shuikuan);
    }
    else if (perm > 12000) {
      shuikuan = money * 0.2 - 1410;
      return Number(shuikuan);
    }
    else if (perm > 3000) {
      shuikuan = money * 0.10 - 210;
      return Number(shuikuan);
    }
    else{
      shuikuan = money*0.03;
      return Number(shuikuan);
    }

  },

  shuilv:function(perm){
    if (perm > 80000){
      this.setData({
        rate:"45%"
      })
    }
    else if (perm > 55000){
      this.setData({
        rate:"35%"
      })
    }
    else if (perm > 35000) {
      this.setData({
        rate: "30%"
      })
    } 
    else if (perm > 25000) {
      this.setData({
        rate: "25%"
      })
    } 
    else if (perm > 12000) {
      this.setData({
        rate: "20%"
      })
    } 
    else if (perm > 3000) {
      this.setData({
        rate: "10%"
      })
    }
    else {
      this.setData({
        rate: "3%"
      })
    }

    
  },

  calculateBtn: function (e) {
    if (!this.data.income) {
      wx.showToast({
        title: '请输入年终奖金额'
      })
      return false;
    }
    else{
      var money = this.data.income;
      var perm = this.data.income/12;
      var shuikuan = this.nianzhongjiang(money);
      this.shuilv(perm);

      this.setData({
        taxPayable:shuikuan,
        perMonth:Math.round(perm),
        score:money-shuikuan
      })
    }

  },



})