Page({
  onShow() {
    wx.reportAnalytics('enter_home_programmatically', {})
  },

  data: {
    list: [
      {
        id: 'housework',
        name: '家务选择',
        open: false,
        pages: ['housework']
      }, {
        id: 'tax',
        name: '税务计算',
        open: false,
        pages: ['wages tax', 'interest tax', 'year-end tax', 'accidental tax']
      }, {
        id: 'child',
        name: '养娃预算',
        open: false,
        pages: ['baby']
      }, {
        id: 'bmi',
        name: '健康评估',
        open: false,
        pages: ['BMI']
      }
    ]
  },

  kindToggle(e) {
    const id = e.currentTarget.id
    const list = this.data.list
    for (let i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        list[i].open = !list[i].open
      } else {
        list[i].open = false
      }
    }
    this.setData({
      list
    })
    wx.reportAnalytics('click_view_programmatically', {})
  }
})
