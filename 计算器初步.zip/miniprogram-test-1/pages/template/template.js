
//初始化数据
function tabbarinit() {
  return [
    {
      "current": 0,
      "pagePath": "/pages/cal/cal",
      "iconPath": "/images/calculator.png",
      "selectedIconPath": "/images/calculator.png",
      "text": "计算器"
    },
    {
      "current": 0,
      "pagePath": "/pages/home/home",
      "iconPath": "/images/homepage.png",
      "selectedIconPath": "/images/homepage.png",
      "text": "主页"

    },
    {
      "current": 0,
      "pagePath": "/pages/task/task",
      "iconPath": "/images/tasklist.png",
      "selectedIconPath": "/images/tasklist.png",
      "text": "任务"
    }
  ]

}
//tabbar 主入口
function tabbarmain(bindName = "tabdata", id, target) {
  var that = target;
  var bindData = {};
  var otabbar = tabbarinit();
  otabbar[id]['iconPath'] = otabbar[id]['selectedIconPath']//换当前的icon
  otabbar[id]['current'] = 1;
  bindData[bindName] = otabbar
  that.setData({ bindData });
}

module.exports = {
  tabbar: tabbarmain
}